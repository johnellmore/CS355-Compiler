// Dwayne Towell -- CS 355 Compiler Construction

#include "Compiler.h"

int main() {
	Tokenizer tokenizer(cin,cout);
	Parser parser;
	if (!parser.parse(&tokenizer))
		return 0;
	Module * module = parser.getModule();
	
	Dump dump;
	cout << module->apply(dump);
	return 0;
}
