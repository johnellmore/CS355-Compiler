
g++ -Wall Token.cpp Tokenizer.cpp Parser.cpp tests/ParserTest.cpp

# These files work
echo "These files should be successfully parsed:"
./a.out q/0-empty.q
./a.out q/1-increment.q
./a.out q/2-arraysearch.q

# These files don't work
echo "These files should fail parsing:"
./a.out q/e-0-deadsimpleerror.q
./a.out q/e-1-functiondec.q
./a.out q/e-2-badarraysearch.q
./a.out q/e-3-missingexpressionargument.q
./a.out q/e-4-invalidarrayindex.q
