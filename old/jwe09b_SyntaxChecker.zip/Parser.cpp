#include <iostream>
using namespace std;

#include "Token.h"
#include "Tokenizer.h"
#include "Parser.h"

bool Parser::parse(Tokenizer *t) {
	tokenizer = t;
	return parseModule();
}

bool Parser::parseModule() {
	LOG << "parsing module" << endl;
	if (tokenizer->check(TT_END))
		return tokenizer->peek(TT_EOF);
	
	if (tokenizer->check(TT_VARS))
		return parseDeclarationList()
			&& tokenizer->check(TT_END)
			&& parseModule();
	
	if (tokenizer->check(TT_FUNCTION))
		return parseFunctionSignature()
			&& parseFunctionBody()
			&& parseModule();
	
	return false;
}

bool Parser::parseFunctionSignature() {
	LOG << "parsing function signature" << endl;
	
	if (tokenizer->check(TT_IDENTIFIER)
	 && tokenizer->check(TT_COLON)
	 && parseScalarType()) {
		if (tokenizer->peek(TT_IDENTIFIER)) return parseDeclarationList(); // declaration list
		return true; // dec list is optional
	}
	
	return false;
}

bool Parser::parseFunctionBody() {
	LOG << "parsing function body" << endl;
	
	// vars DL do SL return E
	if (tokenizer->check(TT_VARS))
		return parseDeclarationList()
			&& tokenizer->check(TT_DO)
			&& parseStatementList()
			&& tokenizer->check(TT_RETURN)
			&& parseExpression();
	
	// do SL return E
	if (tokenizer->check(TT_DO))
		return parseStatementList()
			&& tokenizer->check(TT_RETURN)
			&& parseExpression();
	
	if (tokenizer->check(TT_RETURN))
		return parseExpression();
	
	return tokenizer->check(TT_END);
}

bool Parser::parseDeclarationList() {
	LOG << "parsing declaration list" << endl;
	
	if (parseVariableDeclaration()) {
		if (tokenizer->check(TT_SEMICOLON)) return parseDeclarationList();
		else return true;
	}
	
	return false;
}

bool Parser::parseVariableDeclaration() {
	LOG << "parsing variable declaration" << endl;
	
	return tokenizer->check(TT_IDENTIFIER)
		&& tokenizer->check(TT_COLON)
		&& parseType();
}

bool Parser::parseType() {
	LOG << "parsing type" << endl;
	
	if (parseScalarType()) {
		if (tokenizer->check(TT_OPEN_ARRAY))
			return tokenizer->check(TT_CONSTANT)
				&& tokenizer->check(TT_CLOSE_ARRAY);
		return true;
	}
	
	return false;
}

bool Parser::parseScalarType() {
	LOG << "parsing scalar type" << endl;
	
	return tokenizer->check(TT_BOOL)
		|| tokenizer->check(TT_BYTE)
		|| tokenizer->check(TT_SHORT)
		|| tokenizer->check(TT_LONG);
}

bool Parser::parseExpression() {
	LOG << "parsing expression" << endl;
	
	// all binary postfix operators
	if (tokenizer->check(TT_PLUS)
	 || tokenizer->check(TT_MINUS)
	 || tokenizer->check(TT_MULTIPLY)
	 || tokenizer->check(TT_DIVIDE)
	 || tokenizer->check(TT_MOD)
	 || tokenizer->check(TT_NEG)
	 || tokenizer->check(TT_LESS_THAN)
	 || tokenizer->check(TT_GREATER_THAN)
	 || tokenizer->check(TT_LESS_THAN_OR_EQUAL)
	 || tokenizer->check(TT_GREATER_THAN_OR_EQUAL)
	 || tokenizer->check(TT_EQUAL)
	 || tokenizer->check(TT_NOT_EQUAL)
	 || tokenizer->check(TT_AND)
	 || tokenizer->check(TT_OR)
	 || tokenizer->check(TT_NOT))
		return parseExpression()
			&& parseExpression();
	
	// single things (constants, bools, l-values)
	if (tokenizer->check(TT_CONSTANT)
	 || tokenizer->check(TT_TRUE)
	 || tokenizer->check(TT_FALSE)
	 || parseLValue())
		return true;
	
	// increment and decrement
	if (tokenizer->check(TT_INC)
	 || tokenizer->check(TT_DEC))
		return parseLValue();
	
	// function call
	return tokenizer->check(TT_IDENTIFIER)
		&& parseParameterList();
}

bool Parser::parseLValue() {
	LOG << "parsing l value" << endl;
	
	if (tokenizer->check(TT_IDENTIFIER)) {
		if (tokenizer->check(TT_OPEN_ARRAY))
			return parseExpression()
				&& tokenizer->check(TT_CLOSE_ARRAY);
		return true;
	}
	
	return false;
}

bool Parser::parseParameterList() {
	LOG << "parsing parameter list" << endl;
	
	if (tokenizer->check(TT_BANG)) return true;
	
	return parseExpression()
		&& parseParameterList();
	
	return false;
}

bool Parser::parseStatementList() {
	LOG << "parsing statement list" << endl;
	
	if (parseStatement()) {
		if (tokenizer->check(TT_SEMICOLON))
			return parseStatementList();
		return true;
	}
	
	return false;
}

bool Parser::parseStatement() {
	LOG << "parsing statement" << endl;
	
	// set LV E
	if (tokenizer->check(TT_SET))
		return parseLValue()
			&& parseExpression();
	
	// { SL } ...
	if (tokenizer->check(TT_OPEN_COMPOUND)
	 && parseStatementList()
	 && tokenizer->check(TT_CLOSE_COMPOUND)) {
		// { SL } ^ E
		if (tokenizer->check(TT_CARET))
			return parseExpression();
		
		// { SL } if E [...]
		if (tokenizer->check(TT_IF)) {
			return parseExpression();
			
			// { SL } if E else { SL }
			if (tokenizer->check(TT_ELSE))
				return tokenizer->check(TT_OPEN_COMPOUND)
					&& parseStatementList()
					&& tokenizer->check(TT_CLOSE_COMPOUND);
		}
	}
	
	// E
	if (parseExpression()) return true;
	
	return true;
}
