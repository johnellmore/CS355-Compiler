#include <string>
using namespace std;

#include "Token.h"

Token::Token(const string &ntext, TokenType ntype, TokenFlag nflags) :
	text(ntext), type(ntype), flags(nflags) {}

void Token::operator=(const Token &n) {
	text = n.text;
	type = n.type;
	flags = n.flags;
}
