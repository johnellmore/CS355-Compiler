#include <iostream>
#include <list>
using namespace std;

#include "Token.h"
#include "Tokenizer.h"
#include "Parser.h"

bool Parser::parse(Tokenizer *t) {
	tokenizer = t;
	return parseModule();
}

bool Parser::printError(string msg) {
	cerr << "Error @ " << tokenizer->currentPosition().toString() << ": " << msg << endl;
	return false;
}

bool Parser::parseModule() {
	LOG << "parsing module" << endl;
	if (tokenizer->check(TT_END)) {
		if (tokenizer->peek(TT_EOF)) return true;
		return printError("eof expected");
	}
	
	if (tokenizer->check(TT_VARS))
		return parseDeclarationList()
			&& (tokenizer->check(TT_END) || printError("expected end of module variable declarations"))
			&& parseModule();
	
	if (tokenizer->check(TT_FUNCTION))
		return parseFunctionSignature()
			&& parseFunctionBody()
			&& parseModule();
	
	return printError("module expected");
}

bool Parser::parseFunctionSignature() {
	LOG << "parsing function signature" << endl;
	
	if (tokenizer->peek(TT_IDENTIFIER)) {
		if (!tokenizer->isExistingFunction()) {
			tokenizer->nextToken();
			tokenizer->setLastAsFunction();
		} else {
			return printError("redeclaring existing identifier \"" + tokenizer->lastToken()->getText() + "\"");
		}
		if (tokenizer->check(TT_COLON)) {
			if (parseScalarType()) {
				if (tokenizer->peek(TT_IDENTIFIER)) return parseDeclarationList(); // declaration list
				return true; // dec list is optional
			} else return false;
		} else return printError("expected colon after identifier in function signature");
	}
	
	return printError("function signature did not start with an identifier");
}

bool Parser::parseFunctionBody() {
	LOG << "parsing function body" << endl;
	
	if (tokenizer->check(TT_RETURN))
		return parseExpression();
	
	if (tokenizer->check(TT_END)) return true;
	
	// vars DL do SL return E
	if (tokenizer->check(TT_VARS) && !parseDeclarationList()) return false;
	
	// do SL return E
	if (tokenizer->check(TT_DO))
		return parseStatementList()
			&& (tokenizer->check(TT_RETURN) || printError("expected semicolon or return after function statement list"))
			&& parseExpression();
	
	return printError("function do expected");
}

bool Parser::parseDeclarationList() {
	LOG << "parsing declaration list" << endl;
	
	if (parseVariableDeclaration()) {
		if (tokenizer->check(TT_SEMICOLON)) return parseDeclarationList();
		else return true;
	}
	
	return false;
}

bool Parser::parseVariableDeclaration() {
	LOG << "parsing variable declaration" << endl;
	
	return (tokenizer->check(TT_IDENTIFIER) || printError("variable declaration missing starting identifier"))
		&& (tokenizer->check(TT_COLON) || printError("variable declaration missing colon"))
		&& parseType();
}

bool Parser::parseType() {
	LOG << "parsing type" << endl;
	
	if (parseScalarType()) {
		if (tokenizer->check(TT_OPEN_ARRAY))
			return (tokenizer->check(TT_CONSTANT) || printError("expected constant for array length"))
				&& (tokenizer->check(TT_CLOSE_ARRAY) || printError("missing array length closing bracket"));
		return true;
	}
	
	return false;
}

bool Parser::parseScalarType() {
	LOG << "parsing scalar type" << endl;
	
	return tokenizer->check(TT_BOOL)
		|| tokenizer->check(TT_BYTE)
		|| tokenizer->check(TT_SHORT)
		|| tokenizer->check(TT_LONG)
		|| printError("invalid scalar type");
}

bool Parser::parseExpression() {
	LOG << "parsing expression" << endl;
	
	// all binary postfix operators
	if (tokenizer->check(TT_PLUS)
	 || tokenizer->check(TT_MINUS)
	 || tokenizer->check(TT_MULTIPLY)
	 || tokenizer->check(TT_DIVIDE)
	 || tokenizer->check(TT_MOD)
	 || tokenizer->check(TT_NEG)
	 || tokenizer->check(TT_LESS_THAN)
	 || tokenizer->check(TT_GREATER_THAN)
	 || tokenizer->check(TT_LESS_THAN_OR_EQUAL)
	 || tokenizer->check(TT_GREATER_THAN_OR_EQUAL)
	 || tokenizer->check(TT_EQUAL)
	 || tokenizer->check(TT_NOT_EQUAL)
	 || tokenizer->check(TT_AND)
	 || tokenizer->check(TT_OR)
	 || tokenizer->check(TT_NOT))
		return parseExpression()
			&& parseExpression();
	
	// single things (constants, bools, l-values)
	if (tokenizer->check(TT_CONSTANT)
	 || tokenizer->check(TT_TRUE)
	 || tokenizer->check(TT_FALSE))
		return true;
	
	// increment and decrement
	if (tokenizer->check(TT_INC)
	 || tokenizer->check(TT_DEC))
		return parseLValue();
	
	// l-values and function calls
	if (tokenizer->peek(TT_IDENTIFIER)) {
		if (tokenizer->isExistingFunction()) {
			tokenizer->nextToken();
			return parseParameterList();
		} else return parseLValue();
	}
	
	return printError("expression expected");
}

bool Parser::parseLValue() {
	LOG << "parsing l-value" << endl;
	
	if (tokenizer->peek(TT_IDENTIFIER)) {
		if (tokenizer->isExistingFunction()) return printError("expected variable, not function");
		tokenizer->nextToken();
		if (tokenizer->check(TT_OPEN_ARRAY))
			return parseExpression()
				&& (tokenizer->check(TT_CLOSE_ARRAY) || printError("expected array close bracket"));
		return true;
	}
	return printError("expected identifier");
}

bool Parser::parseParameterList() {
	LOG << "parsing parameter list" << endl;
	
	if (tokenizer->check(TT_BANG)) return true;
	
	return (parseExpression() || printError("Unexpected end of parameter list"))
		&& parseParameterList();
	
	return false;
}

bool Parser::parseStatementList() {
	LOG << "parsing statement list" << endl;
	
	if (parseStatement()) {
		if (tokenizer->check(TT_SEMICOLON))
			return parseStatementList();
		return true;
	}
	
	return false;
}

bool Parser::parseStatement() {
	LOG << "parsing statement" << endl;
	
	// set LV E
	if (tokenizer->check(TT_SET))
		return parseLValue()
			&& parseExpression();
	
	// { SL } ...
	if (tokenizer->check(TT_OPEN_COMPOUND)
	 && parseStatementList()
	 && (tokenizer->check(TT_CLOSE_COMPOUND) || printError("missing close compound bracket"))) {
		// { SL } ^ E
		if (tokenizer->check(TT_CARET)) {
			return parseExpression();
		} else if (tokenizer->check(TT_IF)) {
			// { SL } if E [...]
			if (!parseExpression()) return false;
			
			// { SL } if E else { SL }
			if (tokenizer->check(TT_ELSE)) {
				return (tokenizer->check(TT_OPEN_COMPOUND) || printError("missing else clause open compound bracket"))
					&& parseStatementList()
					&& (tokenizer->check(TT_CLOSE_COMPOUND) || printError("missing else clause closing compound bracket"));
			} else return true;
		} else return printError("expected loop or if statement");
	}
	
	// E
	if (parseExpression()) return true;
	
	return printError("statement expected");
}
