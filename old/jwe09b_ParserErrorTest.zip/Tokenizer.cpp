#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <list>
#include <map>
using namespace std;

#include "Token.h"
#include "Tokenizer.h"

// common vars
const char wsChars[] = {0x9, 0xA, 0xD, 0x20}; // tab, newline, carriage return, space
const vector <char> whitespace(wsChars, wsChars + sizeof(wsChars) / sizeof(char));
map <string, TokenType> keywords; // populated by initKeywordList();

void initKeywordList() {
	// this is wrapped in a function because I can't populate a map in global scope
	// (as far as I know)
	keywords["bool"] = TT_BOOL;
	keywords["byte"] = TT_BYTE; 
	keywords["short"] = TT_SHORT;
	keywords["long"] = TT_LONG;
	
	keywords["+"] = TT_PLUS;
	keywords["-"] = TT_MINUS;
	keywords["*"] = TT_MULTIPLY;
	keywords["/"] = TT_DIVIDE;
	keywords["%"] = TT_MOD;
	keywords["<"] = TT_LESS_THAN;
	keywords["<="] = TT_LESS_THAN_OR_EQUAL;
	keywords[">"] = TT_GREATER_THAN;
	keywords[">="] = TT_GREATER_THAN_OR_EQUAL;
	keywords["="] = TT_EQUAL;
	keywords["<>"] = TT_NOT_EQUAL;
	keywords["and"] = TT_AND;
	keywords["or"] = TT_OR;
	
	keywords["not"] = TT_NOT;
	keywords["neg"] = TT_NEG;
	keywords["++"] = TT_INC;
	keywords["--"] = TT_DEC;
	
	keywords["true"] = TT_TRUE;
	keywords["false"] = TT_FALSE;
	
	keywords["function"] = TT_FUNCTION;
	keywords["vars"] = TT_VARS;
	keywords["do"] = TT_DO;
	keywords["return"] = TT_RETURN;
	keywords["end"] = TT_END;
	keywords["set"] = TT_SET;
	keywords["if"] = TT_IF;
	keywords["else"] = TT_ELSE;
	keywords["{"] = TT_OPEN_COMPOUND;
	keywords["}"] = TT_CLOSE_COMPOUND;
	keywords["["] = TT_OPEN_ARRAY;
	keywords["]"] = TT_CLOSE_ARRAY;
	keywords[":"] = TT_COLON;
	keywords[";"] = TT_SEMICOLON;
	keywords["^"] = TT_CARET;
	keywords["!"] = TT_BANG;
}

string Position::toString() const {
	stringstream output;
	output << "L" << lineNumber << "C" << character;
	return output.str();
}

// checks if a token is a keyword
bool Tokenizer::isKeyword(const string test) {
	return keywords.find(test) != keywords.end();
}

// checks if a character is whitespace
bool Tokenizer::isWhitespace(const char test) {
	return binary_search(whitespace.begin(), whitespace.end(), test);
}

// checks if a character can be used in an identifier
bool Tokenizer::isIdentifierChar(const char test, const int pos) {
	if (test >= 65 && test <= 90) return true; // uppercase letters
	if (test >= 97 && test <= 122) return true; // lowercase letters
	if (pos && test >= 48 && test <= 57) return true; // numbers (only if not first character)
	return false;
}

bool Tokenizer::isConstantChar(const char test) {
	return (test >= 48 && test <= 57);
}

// construct the Tokenizer object
Tokenizer::Tokenizer(istream &ninput) {
	initKeywordList();
	input = &ninput;
	nextPos.lineNumber = 1;
	nextPos.character = 0;
}

// move to next token
void Tokenizer::nextToken() {
	string curToken; // the current token string
	bool isConstant = false;
	bool maybeIdentifier = true;
	
	while (!input->eof()) {
		// read in one more character
		char thisChar = input->get();
		
		// update position
		if (thisChar == 0xA) { // if char is a newline
			nextPos.lineNumber++;
			nextPos.character = 0;
		} else if (thisChar == 0x9) {
			nextPos.character += 4;
		} else {
			nextPos.character++;
		}
		
		// if new char is whitespace, reset curToken
		if (isWhitespace(thisChar)) {
			if (curToken.size()) {
				// all important tokens will have been caught. This token must be invalid.
				return pushToken(curToken, TT_INVALID);
			} else {
				curToken = "";
				continue;
			}
		} else if (!curToken.size()) {
			curPos = nextPos;
		}
		curToken += thisChar;
		
		// see if the current token string matches a reserved word
		if (isKeyword(curToken)) {
			// check if concatenation of next char is a keyword
			string nextTest(curToken);
			nextTest += input->peek();
			if (isKeyword(nextTest)) {
				continue; // let next iteration catch keyword
			} else {
				// we got ourselves a keyword to tokenize
				return pushToken(curToken, keywords[curToken]);
			}
		}
		
		// check if this is a constant
		if ((isConstant || curToken.size() == 1) && isConstantChar(thisChar)) {
			isConstant = true;
			if (isConstantChar(input->peek())) {
				continue; // keep processing 
			} else {
				// we've got ourselves a constant
				return pushToken(curToken, TT_CONSTANT);
			}
		}
		
		// check if this is an identifier
		if (maybeIdentifier) {
			if (isIdentifierChar(thisChar, curToken.size()-1)) {
				if (isIdentifierChar(input->peek(), 1)) {
					continue; // keep processing 
				} else {
					// we've got ourselves a constant
					return pushToken(curToken, TT_IDENTIFIER);
				}
			} else {
				maybeIdentifier = false;
				continue;
			}
		}
		
	}
	return pushToken(curToken, TT_EOF);
}

// look at the current token
bool Tokenizer::peek(TokenType expected) {
	return symbols.begin()->getType() == expected;
}

// look at the current token and skip if it matches
bool Tokenizer::check(const TokenType expected) {
	if (symbols.begin()->getType() == expected) {
		nextToken();
		return true;
	}
	return false;
}

// look at the current token
bool Tokenizer::test(TokenType expected) {
	return (++symbols.begin())->getType() == expected;
}

// get the last (previous) token
Token * Tokenizer::lastToken() {
	TokenList::iterator prev = ++symbols.begin();
	return &(*prev);
}

// get the location of the current token
const Position &Tokenizer::currentPosition() const {
	return curPos;
}

void Tokenizer::pushToken(const string &text, TokenType type, TokenFlag flags) {
	Token newest(text, type, flags);
	symbols.push_front(newest);
	LOG << "Token: " << "\"" << text << "\"" << " of type " << type << " @ " << curPos.toString() << endl;
}

void Tokenizer::setLastAsFunction() {
	// set previous token to a function
	Token * prev = lastToken();
	prev->setAsFunction();
}

bool Tokenizer::areTokensSameText(const Token &test1, const Token &test2) {
	return (test1.getText() == test2.getText());
}

bool Tokenizer::areTokensExactSame(const Token &test1, const Token &test2) {
	return (test1.getText() == test2.getText() &&
			test1.hasAttribute(TF_FUNCTION) == test2.hasAttribute(TF_FUNCTION));
}

bool Tokenizer::isExistingSymbol() {
	TokenList::iterator first = symbols.begin();
	if (first->getType() != TT_IDENTIFIER) return false;
	TokenList::iterator historyBegin = first;
	TokenList checkList(first, ++historyBegin);
	TokenList::iterator check = search(historyBegin, symbols.end(), checkList.begin(), checkList.end(), areTokensSameText);
	return (check != symbols.end());
}

bool Tokenizer::isExistingFunction() {
	Token * check = &*(symbols.begin());
	TokenList::reverse_iterator rit;
	for (rit = symbols.rbegin(); rit != symbols.rend(); ++rit) {
		if (rit->hasAttribute(TF_FUNCTION)
		 && rit->getText() == check->getText()) return true;
	}
	return false;
}
