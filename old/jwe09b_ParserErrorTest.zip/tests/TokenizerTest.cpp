#include <iostream>
#include <sstream>
#include <cassert>
using namespace std;

#include "Token.h"
#include "Tokenizer.h"

stringstream input;
Tokenizer *t;
bool tIsSetup = false;

void setup(string in) {
	if (tIsSetup) delete t;
	else tIsSetup = true;
	LOG << "Setting up!" << endl;
	input.seekg(0, ios::beg);
	input.str(in);
	t = new Tokenizer(input);
}

void verify(TokenType tt,int line,int character, string ident="") {
	t->nextToken();
	assert(t->peek(tt));
	assert(t->currentPosition().lineNumber==line);
	assert(t->currentPosition().character==character);
	if (ident.size()) {
		assert(t->lastToken()->getText() == ident);
	}
	// TODO verify other properties of Token
	// TODO verify other properties of Tokenizer
}

int main () {
	// test #1
	setup("function x:long\na:short\nreturn x\nend");
	verify(TT_FUNCTION,1,1);
	verify(TT_IDENTIFIER,1,10,"x");
	verify(TT_COLON,1,11);
	verify(TT_LONG,1,12);
	verify(TT_IDENTIFIER,2,1,"a");
	verify(TT_COLON,2,2);
	verify(TT_SHORT,2,3);
	verify(TT_RETURN,3,1);
	verify(TT_IDENTIFIER,3,8,"x");
	verify(TT_END,4,1);
	
	// test #2
	setup("function increment:short number:short do\nset number + number 1\nreturn number\nend\nend");
	// line 1
	verify(TT_FUNCTION,1,1);
	verify(TT_IDENTIFIER,1,10,"increment");
	verify(TT_COLON,1,19);
	verify(TT_SHORT,1,20);
	verify(TT_IDENTIFIER,1,26,"number");
	verify(TT_COLON,1,32);
	verify(TT_SHORT,1,33);
	verify(TT_DO,1,39);
	// line 2
	verify(TT_SET,2,1);
	verify(TT_IDENTIFIER,2,5,"number");
	verify(TT_PLUS,2,12);
	verify(TT_IDENTIFIER,2,14,"number");
	verify(TT_CONSTANT,2,21,"1");
	// line 3
	verify(TT_RETURN,3,1);
	verify(TT_IDENTIFIER,3,8,"number");
	// lines 4 & 5
	verify(TT_END,4,1);
	verify(TT_END,5,1);
	
	// test #3
	setup("function position:short needle:short haystack:short[10]\nvars i:short do\nset i 0\n{\n{\nreturn needle\n} if = haystack[i] needle\n++ i\n} ^ < i 10\nreturn neg 1\nend\nend");
	// line 1
	verify(TT_FUNCTION,1,1);
	verify(TT_IDENTIFIER,1,10,"position");
	verify(TT_COLON,1,18);
	verify(TT_SHORT,1,19);
	verify(TT_IDENTIFIER,1,25,"needle");
	verify(TT_COLON,1,31);
	verify(TT_SHORT,1,32);
	verify(TT_IDENTIFIER,1,38,"haystack");
	verify(TT_COLON,1,46);
	verify(TT_SHORT,1,47);
	verify(TT_OPEN_ARRAY,1,52);
	verify(TT_CONSTANT,1,53);
	verify(TT_CLOSE_ARRAY,1,55);
	// line 2
	verify(TT_VARS,2,1);
	verify(TT_IDENTIFIER,2,6,"i");
	verify(TT_COLON,2,7);
	verify(TT_SHORT,2,8);
	verify(TT_DO,2,14);
	// line 3
	verify(TT_SET,3,1);
	verify(TT_IDENTIFIER,3,5,"i");
	verify(TT_CONSTANT,3,7, "0");
	// lines 4 & 5 
	verify(TT_OPEN_COMPOUND,4,1);
	verify(TT_OPEN_COMPOUND,5,1);
	// line 6 
	verify(TT_RETURN,6,1);
	verify(TT_IDENTIFIER,6,8,"needle");
	// line 7
	verify(TT_CLOSE_COMPOUND,7,1);
	verify(TT_IF,7,3);
	verify(TT_EQUAL,7,6);
	verify(TT_IDENTIFIER,7,8,"haystack");
	verify(TT_OPEN_ARRAY,7,16);
	verify(TT_IDENTIFIER,7,17,"i");
	verify(TT_CLOSE_ARRAY,7,18);
	verify(TT_IDENTIFIER,7,20,"needle");
	// line 8
	verify(TT_INC,8,1);
	verify(TT_IDENTIFIER,8,4,"i");
	// line 9
	verify(TT_CLOSE_COMPOUND,9,1);
	verify(TT_CARET,9,3);
	verify(TT_LESS_THAN,9,5);
	verify(TT_IDENTIFIER,9,7,"i");
	verify(TT_CONSTANT,9,9,"10");
	// line 10
	verify(TT_RETURN,10,1);
	verify(TT_NEG,10,8);
	verify(TT_CONSTANT,10,12,"1");
	// lines 11 & 12
	verify(TT_END,11,1);
	verify(TT_END,12,1);
	
	delete t;
}
